QZIX TOKEN - FREE PWA DEMO
1. Upload all files in this folder to a static host (for example GitHub Pages).
2. Open the website on Android Chrome.
3. Use Chrome menu > Add to Home screen / Install app.

IMPORTANT:
This is a front-end local demo only. It stores demo data in the current browser.
It does not provide real multi-user accounts, secure ownership, payment processing,
live trading, or a shared database. Those require a backend/database and security review.
The ₹2 amount is a resale reference after all 100 company tokens are sold; company
cannot sell additional tokens because total supply is fixed at 100.
